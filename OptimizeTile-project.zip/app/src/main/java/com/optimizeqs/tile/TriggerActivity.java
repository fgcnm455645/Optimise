package com.optimizeqs.tile;

import android.app.Activity;
import android.os.Bundle;

/**
 * Shows nothing at all: it closes itself immediately.
 * (Theme.NoDisplay requires finish() inside onCreate.)
 */
public class TriggerActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        finish();
        overridePendingTransition(0, 0);
    }
}
