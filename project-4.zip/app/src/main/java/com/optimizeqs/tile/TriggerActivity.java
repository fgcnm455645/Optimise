package com.optimizeqs.tile;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;

/**
 * Invisible activity. It stays in the foreground for a moment so that
 * Bixby Routines ("If: app opened") notices it, then closes itself.
 */
public class TriggerActivity extends Activity {

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable closer = new Runnable() {
        @Override
        public void run() {
            finish();
            overridePendingTransition(0, 0);
        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        handler.removeCallbacks(closer);
        handler.postDelayed(closer, 700);
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
